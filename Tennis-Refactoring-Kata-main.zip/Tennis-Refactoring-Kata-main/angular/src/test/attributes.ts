export const classKey = 'class';
export const idKey = 'id';
