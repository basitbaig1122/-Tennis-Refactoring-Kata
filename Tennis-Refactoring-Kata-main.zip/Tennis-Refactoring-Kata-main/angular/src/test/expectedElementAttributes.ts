export const maxScore = '100';
export const minScore = '0';
export const numberType = 'number';
