 abstract class TennisGame {
    void wonPoint(String playerName);
    String getScore();
}
