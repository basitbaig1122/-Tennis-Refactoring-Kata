// swift-tools-version:5.3

import PackageDescription

let package = Package(
    name: "Tennis",
    products: [
    ],
    targets: [
        .testTarget(
            name: "TennisTests",
            dependencies: [],
            path: ""
        ),
    ]
)
