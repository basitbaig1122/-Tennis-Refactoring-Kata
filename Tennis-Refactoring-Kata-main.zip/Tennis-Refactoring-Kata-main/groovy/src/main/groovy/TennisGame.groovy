
public interface TennisGame {
    void wonPoint(playerName)
    def getScore()
}