package tennis

trait TennisGame {
  def wonPoint(x : String )
  def calculateScore() : String
}
