# Tennis-Refactoring-Kata C++

This uses a simple c-assert test runner.
