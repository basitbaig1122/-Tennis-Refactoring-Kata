module Tenniskata

won_point(game, playerName::String) = error("Not implemented.")
get_score(game) = error("Not implemented.")

end