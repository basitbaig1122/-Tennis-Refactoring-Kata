rootProject.name = "tennis-kata"
