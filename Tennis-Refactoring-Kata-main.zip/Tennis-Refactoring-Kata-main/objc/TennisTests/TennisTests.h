#import <SenTestingKit/SenTestingKit.h>

@interface TennisTests : SenTestCase
- (id)initWithInvocation:(NSInvocation *)invocation scores:(NSArray *)scores;
@end
